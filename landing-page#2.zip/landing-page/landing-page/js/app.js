/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/
/**
 * Define Global Variables
 * 
*/
//selecting all sections created in HTML to loop through them and create the navbar accordingly
const sections = document.querySelectorAll('section');
// selecting the 'ul' created in HTML to append the navbar to it
const navbar = document.querySelector('#navbar__list');
/**
 * End Global Variables
 * Start Helper Functions
 *
*/
// a function to highlight the navbar link that corresponds to the active section that's being viewed
function activeNavLink(activeSection)
{
    const links= document.querySelectorAll('a');
    for(let link of links)
    {
        link.classList.remove('active');
        let sectionNav = activeSection.getAttribute('data-nav');
        if(link.textContent == sectionNav)//checking to see if the textContent of the link matches that of the active section that's being viewed
        {link.classList.add('active');}
    }
}
// a function to scroll to the section associated with the clicked link
function scrollFunction(event)
{
    const clickedLink = event.target.getAttribute('href');
    const element= document.querySelector(clickedLink);
    event.preventDefault();
    element.scrollIntoView({behavior:'smooth',block:'end'});
}
/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/
// build the nav
function createNavbar()
{
    for(let section of sections)
    {
        const navbarItem = document.createElement('li');
        const itemData= section.getAttribute('data-nav');
        const itemId= section.getAttribute('id');//Storing te values of the data-nav and id in variables to use them later when creating each link
        const htmlText= `<a href="#${itemId}">${itemData}</a>`;
        navbarItem.className= 'menu__link'; //creating a class for styling
        navbarItem.insertAdjacentHTML('afterbegin',htmlText);
        navbar.appendChild(navbarItem);
    }
}
// Add class 'active' to section when near top of viewport
function activeClass()
{
    for(let section of sections)
    {
        section.classList.remove('active');
        const position = section.getBoundingClientRect();
        if(position.top >=0 && position.left >=0 &&
            (position.bottom <= window.innerHeight+200|| position.bottom <= document.documentElement.clientHeight+200) &&
            (position.right <=window.innerWidth || position.right <= document.documentElement.clientWidth)
           ) //checking to see if the section is currently within the viewport of the page
        {
            section.classList.add('active');
            activeNavLink(section);//calling the function that highlights the link corresponding to the active section 
        }
    }
}
// Scroll to anchor ID using scrollTO event  

/**
 * End Main Functions
 * Begin Events
 * 
*/
// Build menu 
createNavbar();
// Scroll to section on link click
navbar.addEventListener('click',function(event){scrollFunction(event);});
// Set sections as active
window.addEventListener('scroll',function(){activeClass();});
//hide fixed navigation bar while not scrolling
let countTime;//a variable to store the return value of the setTimeout function
document.addEventListener('scroll',function(){
    if(countTime != 0)//if the timer that was set by the (setTimeout) function is still running and not finished yet
    {clearTimeout(countTime);}//clear the timer and stop the function
    navbar.style.display='block';
    countTime=setTimeout(function(){navbar.style.display='none';},3000);
});
//scroll to top button
$(document).ready(function()
{
    const scrollButton = $('#scroll');
    $(window).scroll(function()
        {
            if($(this).scrollTop() >= 400)
            {scrollButton.show();}
            else
            {scrollButton.hide();}
        });
    scrollButton.click(function()
        {
            $('html,body').animate({scrollTop:0},650);
        });
});
// responsive navigation bar
const icon = document.querySelector('.burger__icon');
icon.addEventListener('click',function()
    {
        if(navbar.style.display==='block')
            {navbar.style.display='none';}
        else
            {navbar.style.display='block';}
    });